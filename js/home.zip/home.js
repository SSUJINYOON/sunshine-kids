$(function(){
  /* carousel------------------------------------------- */
  responsive_carousel_horz(".home-visual", false, 3000, 10000) 
  bubble('.bubble','./img/bubble')
  /* section1,2 motion-------------------------------------------- */
  function fn(){
    $('.home-section1 li, .home-section2 li').each(function(){
      var t = $(this).offset().top
      if(scry >= t - winh * 0.8){
        $(this).addClass('active')
      }else{
        $(this).removeClass('active')
      }
    })
  }//fn
  fn()
  $(window).scroll(function(){
    fn()
  }).resize(function(){
    fn()
  })//win event
})//ready  